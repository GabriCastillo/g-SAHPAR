package es.uma.ingsoftware.SAHPAR.model;

import javax.persistence.Entity;

@Entity
public class Enfermero extends Usuario {
	public Enfermero() {

	}
}
