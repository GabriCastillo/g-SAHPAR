package es.uma.ingsoftware.SAHPAR.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

import es.uma.ingsoftware.SAHPAR.model.Usuario;
import es.uma.ingsoftware.SAHPAR.repository.UsuarioRepository;

@Service
public class UsuarioService  {
	@Autowired
	UsuarioRepository usuarioRepository;
	
	public List<Usuario> getAll() {
		return usuarioRepository.findAll();
	}
	
	public void save(Usuario u) {
		 usuarioRepository.saveAndFlush(u);
	}
	
	@SuppressWarnings("deprecation")
	public Usuario getById(String dni) {
		return usuarioRepository.getOne(dni);
	}
	public void delete(String dni) {
		usuarioRepository.deleteById(dni);
	}
}



