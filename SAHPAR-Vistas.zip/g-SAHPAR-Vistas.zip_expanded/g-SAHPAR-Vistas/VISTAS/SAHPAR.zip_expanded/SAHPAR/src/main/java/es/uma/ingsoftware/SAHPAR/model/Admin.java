package es.uma.ingsoftware.SAHPAR.model;

import javax.persistence.*;

@Entity
public class Admin extends Usuario {

	public Admin() {
		super();
	}
}
