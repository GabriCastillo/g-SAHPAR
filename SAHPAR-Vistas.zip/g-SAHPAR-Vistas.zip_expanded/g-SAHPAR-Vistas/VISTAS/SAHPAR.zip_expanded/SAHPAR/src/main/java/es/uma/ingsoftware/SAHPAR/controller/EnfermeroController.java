package es.uma.ingsoftware.SAHPAR.controller;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import antlr.collections.List;

@Controller
public class EnfermeroController {
	
		@RequestMapping("/enfermero")
		public String enfermeroPage() {
			return "enfermero/index";
		}
	
		@RequestMapping("/enfermero/listadoUsuarios")
		public String listadoUsuarios() { //ENTRE PARÉNTESIS IRÍA: (Model model)
			/*List<Usuario> usuarios = new ArrayList<>(); -- CLASE USUARIO, ENFERMERO, DOCTOR Y enfermero SON SUBCLASES
			AQUÍ SE PODRÍAN AÑADIR USUARIOS
			model.addAttribute("listaUsuarios", usuarios);
			*/
			return "enfermero/listaUsuarios";
		}
		
		@RequestMapping("/enfermero/addUsuario")
		public String addUsuario() {
			return "enfermero/add";
			}

		@RequestMapping("/enfermero/editUsuario/{id}")
		public String editUsuario() {
			return "enfermero/edit";
		}
		
		@RequestMapping("/enfermero/deleteUsuario/{id}")
		public String deleteUsuario() {
			return "redirect:/enfermero/listadoUsuarios";
		}

		@RequestMapping("/enfermero/listadoPacientes")
		public String listadoPacientes() {
			return "enfermero/listaPacientes";
		}
		@RequestMapping("/enfermero/addPaciente")
		public String addPaciente() {
			return "enfermero/addPac";
			}

		@RequestMapping("/enfermero/editPaciente/{id}")
		public String editPaciente() {
			return "enfermero/editPac";
		}
		
		@RequestMapping("/enfermero/deletePaciente/{id}")
		public String deletePaciente() {
			return "redirect:/enfermero/listadoPacientes";
		}




}


