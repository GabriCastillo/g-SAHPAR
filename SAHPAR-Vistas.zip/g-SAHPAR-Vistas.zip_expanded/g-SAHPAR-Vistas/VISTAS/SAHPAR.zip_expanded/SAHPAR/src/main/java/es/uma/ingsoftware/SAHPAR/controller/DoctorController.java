package es.uma.ingsoftware.SAHPAR.controller;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import antlr.collections.List;

@Controller
public class DoctorController {
	
		@RequestMapping("/doctor")
		public String doctorPage() {
			return "doctor/index";
		}
	
		@RequestMapping("/doctor/listadoUsuarios")
		public String listadoUsuarios() { //ENTRE PARÉNTESIS IRÍA: (Model model)
			/*List<Usuario> usuarios = new ArrayList<>(); -- CLASE USUARIO, doctor, DOCTOR Y doctor SON SUBCLASES
			AQUÍ SE PODRÍAN AÑADIR USUARIOS
			model.addAttribute("listaUsuarios", usuarios);
			*/
			return "doctor/listaUsuarios";
		}
		
		@RequestMapping("/doctor/addUsuario")
		public String addUsuario() {
			return "doctor/add";
			}

		@RequestMapping("/doctor/editUsuario/{id}")
		public String editUsuario() {
			return "doctor/edit";
		}
		
		@RequestMapping("/doctor/deleteUsuario/{id}")
		public String deleteUsuario() {
			return "redirect:/doctor/listadoUsuarios";
		}

		@RequestMapping("/doctor/listadoPacientes")
		public String listadoPacientes() {
			return "doctor/listaPacientes";
		}
		@RequestMapping("/doctor/addPaciente")
		public String addPaciente() {
			return "doctor/addPac";
			}

		@RequestMapping("/doctor/editPaciente/{id}")
		public String editPaciente() {
			return "doctor/editPac";
		}
		
		@RequestMapping("/doctor/deletePaciente/{id}")
		public String deletePaciente() {
			return "redirect:/doctor/listadoPacientes";
		}




}

