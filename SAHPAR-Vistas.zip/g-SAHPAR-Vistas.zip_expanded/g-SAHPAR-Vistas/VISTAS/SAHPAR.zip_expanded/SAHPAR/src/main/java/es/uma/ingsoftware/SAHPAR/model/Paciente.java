package es.uma.ingsoftware.SAHPAR.model;

import javax.persistence.*;


@Entity

public class Paciente {
	
	private String nombre;
	private String apellidos;
	private String direccion;
	@Id
	private java.lang.String seguridadSocial;
	private String datosSanitarios;
	private double limiteRojo;
	private double limiteAmarillo;
	private String tlfContacto;
	
	public Paciente() {
		
	}
	
	

	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDireccion() {
		return direccion;
	}
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	public String getSeguridadSocial() {
		return seguridadSocial;
	}
	public void setSeguridadSocial(String seguridadSocial) {
		this.seguridadSocial = seguridadSocial;
	}
	public String getDatosSanitarios() {
		return datosSanitarios;
	}
	public void setDatosSanitarios(String datosSanitarios) {
		this.datosSanitarios = datosSanitarios;
	}
	public double getLimiteRojo() {
		return limiteRojo;
	}
	public void setLimiteRojo(double limiteRojo) {
		this.limiteRojo = limiteRojo;
	}
	public double getLimiteAmarillo() {
		return limiteAmarillo;
	}
	public void setLimiteAmarillo(double limiteAmarillo) {
		this.limiteAmarillo = limiteAmarillo;
	}
	public String getTlfContacto() {
		return tlfContacto;
	}
	public void setTlfContacto(String tlfContacto) {
		this.tlfContacto = tlfContacto;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((apellidos == null) ? 0 : apellidos.hashCode());
		result = prime * result + ((datosSanitarios == null) ? 0 : datosSanitarios.hashCode());
		result = prime * result + ((direccion == null) ? 0 : direccion.hashCode());
		long temp;
		temp = Double.doubleToLongBits(limiteAmarillo);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(limiteRojo);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((nombre == null) ? 0 : nombre.hashCode());
		result = prime * result + ((seguridadSocial == null) ? 0 : seguridadSocial.hashCode());
		result = prime * result + ((tlfContacto == null) ? 0 : tlfContacto.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Paciente other = (Paciente) obj;
		if (apellidos == null) {
			if (other.apellidos != null)
				return false;
		} else if (!apellidos.equals(other.apellidos))
			return false;
		if (datosSanitarios == null) {
			if (other.datosSanitarios != null)
				return false;
		} else if (!datosSanitarios.equals(other.datosSanitarios))
			return false;
		if (direccion == null) {
			if (other.direccion != null)
				return false;
		} else if (!direccion.equals(other.direccion))
			return false;
		if (Double.doubleToLongBits(limiteAmarillo) != Double.doubleToLongBits(other.limiteAmarillo))
			return false;
		if (Double.doubleToLongBits(limiteRojo) != Double.doubleToLongBits(other.limiteRojo))
			return false;
		if (nombre == null) {
			if (other.nombre != null)
				return false;
		} else if (!nombre.equals(other.nombre))
			return false;
		if (seguridadSocial == null) {
			if (other.seguridadSocial != null)
				return false;
		} else if (!seguridadSocial.equals(other.seguridadSocial))
			return false;
		if (tlfContacto == null) {
			if (other.tlfContacto != null)
				return false;
		} else if (!tlfContacto.equals(other.tlfContacto))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Paciente [nombre=" + nombre + ", apellidoselidos=" + apellidos + ", direccion=" + direccion
				+ ", seguridadSocial=" + seguridadSocial + ", datosSanitarios=" + datosSanitarios + ", limiteRojo="
				+ limiteRojo + ", limiteAmarillo=" + limiteAmarillo + ", tlfContacto=" + tlfContacto + "]";
	}

}
