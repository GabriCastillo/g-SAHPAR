package es.uma.ingsoftware.SAHPAR.service;

public class AdminService {

}
