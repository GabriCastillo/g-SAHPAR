package es.uma.ingsoftware.SAHPAR.model;

import javax.persistence.*;

@Entity
public class Doctor extends Usuario {

	public Doctor() {
		
	}
}
